/*ASSIGMENT CPT212
Group members:
	Strong Connectiviy: Nurul Murshida bt Omar Bakri ( 144184 )
	Cycle Detection: 
	Shortest Path: 

*/

#include<iostream>
#include <list>
#include <windows.h>
#include <conio.h>
#include<algorithm>
#include "Graph.h"
//#include "minSpanTree.h"

using namespace std;





// Function that displau main menu
void mainmenu()
{

//	system("cls");
	cout<<"\n\n";
	cout<<"				Assignment II: Graph Algorithms             "<<endl;
	cout<<"\t\t**********************************************************"<<endl;
	cout<<"\t\t [1] Strong Connectivity                      "<<endl;
	cout<<"\t\t [2] Cycle Detection					  "<<endl; 
	cout<<"\t\t [3] Shortest Path "<<endl;
	cout<<"\t\t [4] View graph      "<<endl;
	cout<<"\t\t [5] Reset graph      "<<endl;
	cout<<"\t\t [6] Exit      "<<endl;


	cout<<"\n\tYour choice : ";
}



// graph implementation
int main()
{
	//Initialize object(g1) for Class Graph with initial 5 vertices
	Graph g1(5);
	
	//Initialize graph 
	g1.addEdge(0, 4, 9);
	g1.addEdge(1, 0, 6); 
	g1.addEdge(1, 2, 12); 
	g1.addEdge(3, 2, 4); 
	g1.addEdge(3, 4, 1);
	 
    int choice1,choice2,choice3;
    int count=0;
    int ctdel=0;
    int cycleDel=0;
    int total=5;
	int from, to, wt;
	string ans,disp,ans1;
 //boolean variables for looping/
 	bool loop1,cont;
 	loop1=true;

 while(loop1)
 {

			mainmenu(); // Call fx to display main menu
			cin>>choice1;

			switch(choice1) 
			{
				case 1 :// Function 1 : Strong Connectivity ( Nurul Murshida )
		
						cont=true;
						while(cont)
						{
							bool m;
							bool n;
							
							system("cls");	
							//Main Menu For Function 1
							cout<<"\n\n";
							cout<<" 		  		STRONG CONNECTIVITY   			"<<endl;
							cout<<"\t\t*********************************************"<<endl;
							cout<<"\t\t [1] Check Strong Connectivity              "<<endl;
							cout<<"\t\t [2] Add New Edge					    "<<endl; 
							cout<<"\t\t [3] Delete Edge					  					"<<endl;
							cout<<"\t\t [4] View Graph						  					"<<endl;
							cout<<"\t\t [5] Back					  					"<<endl;

							cout<<"\n\tYour choice : ";
							cin>>choice2;
				
							switch(choice2)
							{
							case 1 ://Check Strong Connectivity and perform generate random edges until its strongly connected
								
								m=g1.isSC();//boolean function to return if the graph is strongly connected or not
								if(m==0)//If the graph is not strongly connected
								{
									cout<<"\n\t This graph does not have Strong Connectivity "<<endl;
									cout<<"\n\n\t Do you wish to proceed ? (Y / N ) --> ";								
									cin>>ans;
									if((ans=="Y")||(ans=="y"))
									{
										cout<<"\n\t We will create Strong Connectivity to the graph...."<<endl;
										cout<<"\n";
										do
										{
											//Generate random edges between random vertices until the graph is strongly connected.
											from= rand() % 5; 
											to= rand() % 5;
											wt= rand() %15;
		
											n=g1.traverse(from,to);//Function to check if the edge is exist or not
		
											if(n==false)
											{
												g1.addEdge(from,to,wt);
												cout<<"\t ADD EDGE " << from << " to " << to <<" -> Weight "<< wt <<endl;
												count++;
											}
		
											m=g1.isSC();//Check again for strong connectivity

										}while(m==0);
										
										if(m==1)
										cout<<"\n\t The graph is now STRONGLY CONNECTED "<<endl;
										cout<<"\n\t New edges that added to the graph : "<<count<<endl;
										total=total+count;
										cout<<"\n\t Total edges : "<<total<<endl;
										
									}
									
									else
									{
									//	proceed=false;
									}
								}
									
								else//Else the graph is strongly connected
								{
									cout<<"\n\t This graph have Strong Connectivity "<<endl;
								}

		    					cout<<"\n\t";
     							system("PAUSE");
			
								break;
				
							case 2 :// Allow user to add new edges
								
								bool add;
								bool k;
								add= true;
								int c;
								int f,t,w;
								while(add==true)
								{
									cout<<"\n\t Enter the edge to add such that ( first - > second ) "<<endl;
									cout<<"\n\t First : ";
									cin>>f;
									cout<<"\n\t Second : ";
									cin>>t;
									cout<<"\n\t Weight : ";
									cin>>w;

									k=g1.traverse(f,t);//Check if the edge already exist or not

									if(k==0)//If the edge does not exist yet
									{
										
									 g1.addEdge(f,t,w);
									 cout<<"\n\t Succesfully add edge " << f << " to " << t <<" -> Weight "<< w <<endl;
									 count=count+1;
									 cout<<"\n\t New edges that added to the graph : "<<count<<endl;
									 total=total+1;
									 cout<<"\n\t Total edges : "<<total<<endl;
										
									}
										
									else//Else the edge is already exist
									{
									 cout<<"\n\t Failed add edge . The edge from "<<f<<" to "<<t<<" already exist! "<<endl;
									}
	
									cout<<"\n\t Do you want to continue add edges ?"<<endl;
									cout<<"\t ";
									cin>>ans;
									if((ans=="N")||(ans=="n"))
										add=false;

								}
								
		    						cout<<"\n\t";
	    							system("PAUSE");
									break;
									
							case 3 ://Allow user to delete edges
							
								add= true;
								while(add==true)
								{
									cout<<"\n\t Enter the edge to delete such that ( first - > second ) "<<endl;
									cout<<"\n\t First : ";
									cin>>f;
									cout<<"\n\t Second : ";
									cin>>t;
									k=g1.traverse(f,t);//Check if the edge exist or not

									if(k==1)//If the edge is exist
									{
										
									 g1.deleteEdge(f,t);
									 cout<<"\n\t Succesfully remove edge " << f << " to " << t  <<endl;
									 ctdel++;
									 cout<<"\n\t Edges remove from the graph : "<<ctdel<<endl;
									 total=total-1;
									 cout<<"\n\t Total edges : "<<total<<endl;
										
									}
										
									else//Else the edge does not exist
									{
									 cout<<"\n\t Failed remove edge . The edge from "<<f<<" to "<<t<<" does not exist! "<<endl;
									}
	
									cout<<"\n\t Do you want to continue remove edges ?"<<endl;
									cout<<"\t ";
									cin>>ans;
									if((ans=="N")||(ans=="n"))
										add=false;

								}
								
		    					cout<<"\n\t";
								system("PAUSE");
								break;

							case 4 ://Allow user to view Graph after modification 

        						g1.display_AdjList();
        						cout<<"\n\t Total edges : "<<total<<endl;
        						cout<<"\n\t";
        						system("PAUSE");
								break;
								
							case 5 ://Go back to Main Menu
									
									cont=false;
									system("cls");
									break;
				
							default: //Input validation for function 1 menu
									{
			 							cout<<"\tInvalid input."<<endl;
	     	 							system("pause");
	    								 system("CLS");
									}
									break;
							
						
			                }//end of switch choice2 ( Function 1 ( Strong Connectivity ) Menu )
	
		               }//end of cont while loop for Function 1 ( Strong Connectivity ) Menu 

		               break;//break of Function 1 ( Strong Connectivity )
			

				
				
		        case 2 : 
						system("cls");
						cont=true;
						while(cont)
						{
						    bool p;
						    bool q;
						    
							system("cls");	
							//Main Menu For Function 1
							cout<<"\n\n";
							cout<<" 		  		CYCLE DETECTION   			"<<endl;
							cout<<"\t\t*********************************************"<<endl;
							cout<<"\t\t [1] Check Cycle              "<<endl;
							cout<<"\t\t [2] Add New Edge					    "<<endl; 
							cout<<"\t\t [3] Delete Edge					  					"<<endl;
							cout<<"\t\t [4] Back					  					"<<endl;

							cout<<"\n\tYour choice : ";
							cin>>choice3;
				
							switch(choice3){
							    
							    case 1:
							        p=g1.isCyclic();//boolean function to return if the graph is cyclic or not
    								if(p==0)//If the graph is not cyclic
    								{
    									cout<<"\n\t This graph does not have cycle "<<endl;
    									cout<<"\n\n\t Do you wish to proceed ? (Y / N ) --> ";								
    									cin>>ans1;
    									if((ans1=="Y")||(ans1=="y"))
    									{
    										cout<<"\n\t We will create Cycle to the graph...."<<endl;
    										cout<<"\n";
    										do
    										{
    											//Generate random edges between random vertices until the graph is cyclic.
    											from= rand() % 5; 
    											to= rand() % 5;
    											wt= rand() %15;
    		
    											q=g1.traverse(from,to);//Function to check if the edge is exist or not
    		
    											if(q==false)
    											{
    												g1.addEdge(from,to,wt);
    												cout<<"\t ADD EDGE " << from << " to " << to <<" -> Weight "<< wt <<endl;
    												count++;
    											}
    		
    											p=g1.isCyclic();//Check again for cyclic
    
    										}while(p==0);
    										
    										if(p==1)
    										cout<<"\n\t The graph is now CYCLIC "<<endl;
    										total=total+count;
    										
    									}
    									
    									else
    									{
    									//	proceed=false;
    									}
    								}
    									
    								else//Else the graph is cyclic
    								{
    									cout<<"\n\t This graph have at least a cycle "<<endl;
    								}
    
    		    					cout<<"\n\t";
         							system("PAUSE");
    			
    								break;
    							    //end case 1
    							    
    							case 2:
    							
    							    bool add1;
    								bool k1;
    								add1= true;
    								int c1;
    								int f1,t1,w1;
    								while(add1==true)
    								{
    									cout<<"\n\t Enter the edge to add such that ( first - > second ) "<<endl;
    									cout<<"\n\t First : ";
    									cin>>f1;
    									cout<<"\n\t Second : ";
    									cin>>t1;
    									cout<<"\n\t Weight : ";
    									cin>>w1;
    
    									k1=g1.traverseCycle(f1,t1);//Check if the edge already exist or not
    
    									if(k1==0)//If the edge does not exist yet
    									{
    										
    									 g1.addEdge(f1,t1,w1);
    									 cout<<"\n\t Succesfully add edge " << f1 << " to " << t1 <<" -> Weight "<< w1 <<endl;
    									 count++;
    									 total=total+1;
    									}
    										
    									else//Else the edge is already exist
    									{
    									 cout<<"\n\t Failed add edge . The edge from "<<f1<<" to "<<t1<<" already exist! "<<endl;
    									}
    	
    									cout<<"\n\t Do you want to continue add edges ?"<<endl;
    									cout<<"\t ";
    									cin>>ans1;
    									if((ans1=="N")||(ans1=="n"))
    										add1=false;
    								}
    								
    		    						cout<<"\n\t";
    	    							system("PAUSE");
    									break;
    									//end case 2
    									
        						case 3://allow user delete edge
        						    add1= true;
    								while(add1==true)
    								{
    									cout<<"\n\t Enter the edge to delete such that first - > second (e.g: 1 -> 2) "<<endl;
    									cout<<"\n\t First : ";
    									cin>>f1;
    									cout<<"\n\t Second : ";
    									cin>>t1;
    									k1=g1.traverseCycle(f1,t1);//Check if the edge exist or not
    
    									if(k1==1)//If the edge is exist
    									{
    										
    									 g1.deleteEdgeCycle(f1,t1);
    									 cout<<"\n\t Succesfully remove edge " << f1 << " to " << t1  <<endl;
    									 cycleDel++;
    									 total=total-1;
    									}
    										
    									else//Else the edge does not exist
    									{
    									 cout<<"\n\t Failed remove edge . The edge from "<<f1<<" to "<<t1<<" does not exist! "<<endl;
    									}
    	
    									cout<<"\n\t Do you want to continue remove edges ?"<<endl;
    									cout<<"\t ";
    									cin>>ans1;
    									if((ans1=="N")||(ans1=="n"))
    										add1=false;
    								}
    								
    		    					cout<<"\n\t";
    								system("PAUSE");
    								break;
    								//end case 3
							    
							    case 4 ://Go back to Main Menu
									
									cont=false;
									system("cls");
									break;
				
							    default: //Input validation for function 1 menu
									{
			 							cout<<"\tInvalid input."<<endl;
	     	 							system("pause");
	    								 system("CLS");
									}
									break;
							    
							}//end switch
						}

					    break;//break of case 2 main menu
						    case 3 : // Shortest Path ( AINA )
					

					break;
				
				case 4 ://View Graph Function
				
						g1.display_AdjList();
        				cout<<"\n\t Total edges : "<<total<<endl;
        				cout<<"\n\t";
        				system("PAUSE");
            			system("CLS");
						break;
				
				case 5 :
					
					// Delete all in the graph by using destructor ?
	
					
					break;
					
			    case 6 :
						system("cls");
						cout<<"\n\n\n\n\t\t___ THANK YOU ___"<<endl;
						return 0;
				
				default :
						cout<<"\n\tPlease enter correct input "<<endl;
				
						
            }// end of switch choice 1  main menu 

        }// end of af switch while loop
    
    
    
}
