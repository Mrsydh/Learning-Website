#include<iostream>
#include <list>
#include <stack>

using namespace std;

class StrongConnect
{
		// Use depth first search to check connectivity
		void DFS(int v, bool visited[]);
    
	public:
	    int V;    // total number of vertices in graph
		list<int> *adj;    //array of adjacency lists 
	    
	    //Function that returns reverse (or transpose) of this graph 
	    StrongConnect TransposeGraph();
	    
		// The main function that returns true if the graph is strongly connected, otherwise false
	    bool isSC();
		
		//Function that traverse the graph to check if the edge is exist or not
		bool traverse(int from , int to);
		
		//Function to delete edge between two vertices
		void deleteEdge(int from , int to);
	   
	    //Function to display the Graph
	    void display_AdjList();
	    
	    StrongConnect(int V);//Constructor 
	    ~StrongConnect();//Destructor

};
 
//Constructor
StrongConnect::StrongConnect(int V)
{ 
	this->V = V;
	adj = new list<int>[V];
}
 
//Destructor
StrongConnect::~StrongConnect() 
{ 
delete [] adj; 
} 
	
// A recursive function to print DFS starting from v 	
void StrongConnect::DFS(int v, bool already_visited[])
{
	// Mark the current node as visited and print it
    already_visited[v] = true;
    
    // Recur for all the vertices adjacent to this vertex 
    list<int>::iterator i;
    
    for (i = adj[v].begin(); i != adj[v].end(); ++i)
        if (!already_visited[*i])
            DFS( *i, already_visited);
            
}
 

 // Function that returns reverse (or transpose) of this graph 
StrongConnect StrongConnect::TransposeGraph()
{
    StrongConnect gg(V);
    for (int v = 0; v < V; v++)
    {
    	// Recur for all the vertices adjacent to this vertex
        list<int>::iterator i;
        
        for(i = adj[v].begin(); i != adj[v].end(); ++i)
        {
            gg.adj[*i].push_back(v);
        }
    }
    return gg;
}
 

bool StrongConnect::isSC()
{
    
    bool already_visited[V];
    
    // Step 1: Mark all the vertices as not visited (For first DFS) 
	for (int i = 0; i < V; i++) 
		already_visited[i] = false; 
	
	// Step 2: Do DFS traversal starting from first vertex. 	
	DFS(0, already_visited);
	
    // If DFS traversal doesn�t visit all vertices, then return false. 
	for (int i = 0; i < V; i++) 
		if (already_visited[i] == false) 
			return false; 

	// Step 3: Create a reversed graph 
    StrongConnect gr = TransposeGraph();// to make reversed graph

	// Step 4: Mark all the vertices as not visited (For second DFS) 
	for(int i = 0; i < V; i++) 
		already_visited[i] = false; 
		
   	gr.DFS(0, already_visited);  //Do DFS for reversed graph starting from first vertex plus must have same start point as first DFS.
 
 
    for (int i = 0; i < V; i++) // then if all vertices is not visited for seocnd time reply false
        if (already_visited[i] == false)
             return false;
 
    return true;
}

bool StrongConnect::traverse(int from, int to)
{ 

	bool found=false;

	list<int>::iterator i;
	for(i = adj[from].begin(); i != adj[from].end(); ++i) 
	{ 
		if (*i==to)
		{
			found=true;
			break;
		}
			
		else
		{
			found=false;
		}
	
	} 

	return found;
} 

void StrongConnect::deleteEdge(int from, int to)
{ 

	bool found;
	found=false;
	stack <int> s;
	int p;
	int x;
	list<int>::iterator i;
	list<int>::iterator u;

	for(i = adj[from].begin(); i != adj[from].end(); ++i) 
	{ 
		if (*i==to)
		{
			found=true;
			break;
		}

		else
		{
			found=false;
		}
	} 
	if(found==true)
	{
		u=i;
		p=0;
		u++;
		while(u != adj[from].end())
		{
			s.push(*u);
			u++;
			p++;				
		}
	
		for(int m=0;m<=p;m++)
		{
			adj[from].pop_back();
		}
	
		for(int m=0;m<p;m++)
		{
			x = s.top();
			adj[from].push_back(x);
			s.pop();
		}

	}


}


// print all adjacent vertices of given vertex
void StrongConnect::display_AdjList()
{
	int no=1;
	cout<<"\n\t Note: ";
	cout<<"\n\t Vertice[0] : HK		Vertice[1] : AU		Vertice[2] : EG	 ";
	cout<<"\n\t Vertice[3] : DK		Vertice[4] : BE	 "<<endl<<endl;; 

    for (int v = 0; v < V; v++)
    {
    	
		list<int>::iterator i;
		for(i = adj[v].begin(); i != adj[v].end(); ++i)
        {
        	cout<<"\t";
        	cout<<"["<<no<<"] ";
    
		switch(v)
    	{	
    		case 0 :
    		 cout  << " From : HK" ;
		 	switch(*i)
			{
				case 0 : cout<<" To : HK " <<endl;
				break;
				case 1 : cout<<" To : AU " <<endl;
				break;
				case 2 : cout<<" To : EG " <<endl;
				break;
				case 3 : cout<<" To : DK " <<endl;
				break;
				case 4 : cout<<" To : BE " <<endl;
				break;
				default :
					cout<<" no destination " <<endl;

			}
			
			break;
    		case 1 :
    		 cout << " From : AU" ;
		 	switch(*i)
			{
				case 0 : cout<<" To : HK " <<endl;
				break;
				case 1 : cout<<" To : AU " <<endl;
				break;
				case 2 : cout<<" To : EG " <<endl;
				break;
				case 3 : cout<<" To : DK " <<endl;
				break;
				case 4 : cout<<" To : BE " <<endl;
				break;
				default :
					cout<<" no destination ";


			}
			
			break;
    		case 2 :
    		 cout<< " From : EG" ;
		 	switch(*i)
			{
				case 0 : cout<<" To : HK " <<endl;
				break;
				case 1 : cout<<" To : AU " <<endl;
				break;
				case 2 : cout<<" To : EG " <<endl;
				break;
				case 3 : cout<<" To : DK " <<endl;
				break;
				case 4 : cout<<" To : BE " <<endl;
				break;
				default :
					cout<<" no destination ";

			}
			
			break;
    		case 3 :
    		 cout << " From : DK" ;
		 	switch(*i)
			{
				case 0 : cout<<" To : HK " <<endl;
				break;
				case 1 : cout<<" To : AU " <<endl;
				break;
				case 2 : cout<<" To : EG " <<endl;
				break;
				case 3 : cout<<" To : DK " <<endl;
				break;
				case 4 : cout<<" To : BE " <<endl;
				break;
				default :
					cout<<" no destination ";

			}
			
			break;

    		case 4 :
    		 cout<< " From : BE" ;
		 	switch(*i)
			{
				case 0 : cout<<" To : HK " <<endl;
				break;
				case 1 : cout<<" To : AU " <<endl;
				break;
				case 2 : cout<<" To : EG " <<endl;
				break;
				case 3 : cout<<" To : DK " <<endl;
				break;
				case 4 : cout<<" To : BE " <<endl;
				break;
				default :
					cout<<" no destination ";

			}
			
			break;
			
			default :
				cout<<" no destination ";
        
    	}//end of switch 
    	
    	no++;
    	
		}//end of inner for
		
   }//end of outer for

}













