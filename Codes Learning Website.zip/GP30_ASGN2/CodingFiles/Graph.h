#include<iostream>
#include <list>
//#include "cycleDetection.h"
//#include "shortPath.h"
#include "StrongConnect.h"
#include "Cycle.h"

using namespace std;

class Graph:  public StrongConnect , public Cycle
{
	public:
	Graph(int v);

	void addEdge(int from, int to, int weight);

};

/*Constuctor*/
Graph::Graph(int v):StrongConnect(v) , Cycle(v)
{


}

/*addEdge*/
void Graph::addEdge(int from, int to, int weight)
{
///	shortPath::adj[from].push_back(to);
	Cycle::adj[from].push_back(to);
	StrongConnect::adj[from].push_back(to);
//	addEdgeSP(from,weight);
}



